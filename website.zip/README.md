# DirectFaucetWebsite
A website about direct working faucet for crypto currency
-------------------------------------------------------------------

A website that list every working direct crypto faucet !
just past your address and receive some token :

  -30 working faucet 
  
  -14 different token 

-------------------------------------------------------------------
